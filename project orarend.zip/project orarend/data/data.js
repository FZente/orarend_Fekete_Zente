const orak = [
    {elso: "Matek", masodik: "Angol", harmadik: "Német", negyedik: "Történelem", otodik: "Testnevelés", hatodik: "Rajz", hetedik: "", nyolcadik: "" },
    {elso: "PHP", masodik: "Javascript", harmadik: "Német", negyedik: "IKT", otodik: "Nyelvtan", hatodik: "Szakang", hetedik: "", nyolcadik: "" },
    {elso: "Fizika", masodik: "Angol", harmadik: "Német", negyedik: "Matek", otodik: "Történelem", hatodik: "", hetedik: "", nyolcadik: ""} ,
    {elso: "Történelem", masodik: "Irodalom", harmadik: "Matek", negyedik: "Szakang", otodik: "Német", hatodik: "Angol", hetedik: "Tesztelés", nyolcadik: "Tesztelés" },
    {elso: "Államp.", masodik: "Történelem", harmadik: "Irodalom", negyedik: "Webprog", otodik: "Testnevelés", hatodik: "Angol", hetedik: "Fejlesztés", nyolcadik: "" },
]

export default orak